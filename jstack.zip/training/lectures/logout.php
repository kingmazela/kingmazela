<?php
  include '../inc/connection.php'; # GET CONNECTION
  session_start(); # START A SESSION
  session_destroy(); # END A SESSION
  header("location: login.php"); #REDIRECT TO LOGIN PAGE
 ?>
