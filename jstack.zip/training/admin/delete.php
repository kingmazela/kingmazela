<?php
  include '../inc/connection.php';
  session_start();

  if (isset($_GET['id'])){ # CHECK ID
    $id = $_GET['id']; # GET ID
    $sql = $db->query("DELETE FROM lecture WHERE id='$id' AND status='hlabi'"); # DELETE USER
    header("location: alllect.php"); # REDIRECT ADMIN

  }

 ?>
