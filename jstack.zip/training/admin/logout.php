<?php
  include '../inc/connection.php';
  session_start(); # START SESSION
  session_destroy(); # DESTROY SESSION
  header("location: login.php"); # REDIRECT

 ?>
